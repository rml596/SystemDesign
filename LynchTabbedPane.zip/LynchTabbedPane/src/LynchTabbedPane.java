import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class LynchTabbedPane extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane TabbedView = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel namePanel = new JPanel();
	private final JLabel lblName = new JLabel("Name");
	private final JTextField nameTextField = new JTextField();
	private final JPanel AddressPanel = new JPanel();
	private final JLabel lblAddress = new JLabel("Address");
	private final JLabel lblCity = new JLabel("City");
	private final JLabel lblState = new JLabel("State");
	private final JTextField addressTextField = new JTextField();
	private final JTextField cityTextField = new JTextField();
	private final JPanel SummaryPanel = new JPanel();
	private final JLabel summaryName = new JLabel("");
	private final JLabel summaryAddress = new JLabel("");
	private final JLabel summaryCity = new JLabel("");
	private final JTextField stateTextField = new JTextField();
	private final JLabel summaryState = new JLabel("");
	private final JLabel lblZip = new JLabel("Zip");
	private final JTextField zipTextField = new JTextField();
	private final JLabel summaryZip = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LynchTabbedPane frame = new LynchTabbedPane();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LynchTabbedPane() {
		zipTextField.setBounds(194, 156, 130, 26);
		zipTextField.setColumns(10);
		cityTextField.setBounds(194, 76, 130, 26);
		cityTextField.setColumns(10);
		addressTextField.setBounds(194, 46, 130, 26);
		addressTextField.setColumns(10);
		nameTextField.setBounds(141, 85, 130, 26);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Lynch Tab Layout");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 679, 433);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		TabbedView.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_TabbedView_stateChanged(e);
			}
		});
		TabbedView.setBounds(6, 6, 667, 399);
		
		contentPane.add(TabbedView);
		
		TabbedView.addTab("Name", null, namePanel, null);
		namePanel.setLayout(null);
		lblName.setBounds(79, 90, 61, 16);
		
		namePanel.add(lblName);
		
		namePanel.add(nameTextField);
		
		TabbedView.addTab("Address", null, AddressPanel, null);
		AddressPanel.setLayout(null);
		lblAddress.setBounds(121, 51, 61, 16);
		
		AddressPanel.add(lblAddress);
		lblCity.setBounds(121, 81, 61, 16);
		
		AddressPanel.add(lblCity);
		lblState.setBounds(121, 119, 61, 16);
		
		AddressPanel.add(lblState);
		
		AddressPanel.add(addressTextField);
		
		AddressPanel.add(cityTextField);
		stateTextField.setColumns(10);
		stateTextField.setBounds(194, 114, 130, 26);
		
		AddressPanel.add(stateTextField);
		lblZip.setBounds(121, 161, 61, 16);
		
		AddressPanel.add(lblZip);
		
		AddressPanel.add(zipTextField);
		
		TabbedView.addTab("Summary", null, SummaryPanel, null);
		SummaryPanel.setLayout(null);
		summaryName.setBounds(94, 29, 121, 16);
		
		SummaryPanel.add(summaryName);
		summaryAddress.setBounds(94, 70, 121, 16);
		
		SummaryPanel.add(summaryAddress);
		summaryCity.setBounds(94, 98, 121, 16);
		
		SummaryPanel.add(summaryCity);
		summaryState.setBounds(94, 126, 121, 16);
		
		SummaryPanel.add(summaryState);
		summaryZip.setBounds(81, 141, 121, 16);
		
		SummaryPanel.add(summaryZip);
	}
	protected void do_TabbedView_stateChanged(ChangeEvent e) {
		if(cityTextField.getText().isEmpty()){
			summaryCity.setForeground(Color.RED);
			summaryCity.setText("Missing City");
		}
		else{
			summaryCity.setText(cityTextField.getText());
			summaryCity.setForeground(Color.BLACK);		
		}
		
		
		if(nameTextField.getText().isEmpty()){
			summaryName.setForeground(Color.RED);
			summaryName.setText("Missing Name");
		}
		else{
			summaryName.setText(nameTextField.getText());
			summaryName.setForeground(Color.BLACK);
		}
		
		
		if(stateTextField.getText().isEmpty()){
			summaryState.setForeground(Color.RED);
			summaryState.setText("Missing State");
		}
		else{
			summaryState.setText(stateTextField.getText());
			summaryState.setForeground(Color.BLACK);
		}
		
		
		if(addressTextField.getText().isEmpty()){
			summaryAddress.setForeground(Color.RED);
			summaryAddress.setText("Missing Address");
		}
		else{
			summaryAddress.setText(addressTextField.getText());
			summaryAddress.setForeground(Color.BLACK);
		}
		
		
		if(zipTextField.getText().isEmpty()){
			summaryZip.setForeground(Color.RED);
			summaryZip.setText("Missing zip");
		}
		else{
			summaryZip.setText(zipTextField.getText());
			summaryZip.setForeground(Color.BLACK);
		}
		
	}
}
