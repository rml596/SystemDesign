import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.List;

import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JMenuBar;
import javax.swing.JSpinner;
import javax.swing.SwingConstants;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeListener;
import javax.swing.text.MaskFormatter;
import javax.swing.event.ChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.text.DecimalFormat;

import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.JFormattedTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JCheckBoxMenuItem;

public class LynchProject1Frame extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel Information = new JPanel();
	private final JLabel lblFirstName = new JLabel("First Name:");
	private final JTextField firstNameTF = new JTextField();
	private final JLabel lblLastName = new JLabel("Last Name:");
	private final JTextField lastNameTF = new JTextField();
	private final JLabel lblAddress = new JLabel("Address:");
	private final JTextField addressTF = new JTextField();
	private final JLabel lblTown = new JLabel("City:");
	private final JComboBox cityComboBox = new JComboBox();
	private final JLabel lblZipCode = new JLabel("Zip Code:");
	private final JFormattedTextField zipTF = new JFormattedTextField();
	MaskFormatter zipMask = createFormatter("#####");
	private final JTextField cityOtherTF = new JTextField();
	private final JMenuBar menuBar = new JMenuBar();
	private final JLabel lblTelephone = new JLabel("Telephone:");
	private final JFormattedTextField telephoneTF = new JFormattedTextField();
	MaskFormatter phoneMask = createFormatter("(###) ###-####");
	private final JLabel lblEmail = new JLabel("Email:");
	private final JTextField emailTF = new JTextField();
	private final JLabel lblAdultNum = new JLabel("# of Adults:");
	private final JSpinner adultSpinner = new JSpinner();
	private final JLabel lblChildren18 = new JLabel("# of Children 18+:");
	private final JLabel lblChildren17 = new JLabel("# of Children 0-17:");
	private final JSpinner child017Spinner = new JSpinner();
	private final JPanel Financials = new JPanel();
	private final JLabel lblIncome = new JLabel("Income");
	private final JSeparator separator = new JSeparator();
	private final JLabel lblExpenses = new JLabel("Expenses");
	private final JLabel lblEmployment = new JLabel("Employment (Total):");
	private final JFormattedTextField totalIncomeTF = new JFormattedTextField();
	MaskFormatter totalIncomeMask = createFormatter("#####");
	private final JLabel lblChildSupport = new JLabel("Child/Spousal Support:");
	private final JFormattedTextField supportIncomeTF = new JFormattedTextField();
	MaskFormatter supportIncomeMask = createFormatter("####");
	private final JLabel ontarioWorksIncome = new JLabel("Ontario Works:");
	private final JFormattedTextField ontarioWorksTF = new JFormattedTextField();
	MaskFormatter ontarioWorkIncomeMask = createFormatter("####");
	private final JLabel lblDisability = new JLabel("E.I. or Disability:");
	private final JFormattedTextField disabilityTF = new JFormattedTextField();
	MaskFormatter disabilityMask = createFormatter("####");
	private final JLabel lblPension = new JLabel("Pension:");
	private final JFormattedTextField pensionTF = new JFormattedTextField();
	MaskFormatter pensionMask = createFormatter("####");
	private final JLabel lblChildTaxCredit = new JLabel("Child Tax Credit");
	private final JFormattedTextField taxCreditTF = new JFormattedTextField();
	MaskFormatter taxCreditMask = createFormatter("####");
	private final JComboBox housePaymentComboBox = new JComboBox();
	private final JLabel lblHome = new JLabel("Home:");
	private final JFormattedTextField rentTF = new JFormattedTextField();
	MaskFormatter rentMask = createFormatter("####");
	private final JLabel lblGasWater = new JLabel("Gas + Water:");
	private final JFormattedTextField gasWaterTF = new JFormattedTextField();
	MaskFormatter gasWaterMask = createFormatter("###");
	private final JLabel lblPhoneTv = new JLabel("Phone + TV");
	private final JFormattedTextField phoneTVTF = new JFormattedTextField();
	MaskFormatter phoneTVMask = createFormatter("###");
	private final JLabel lblChildCare = new JLabel("Child Care:");
	private final JFormattedTextField childCareExpenseTF = new JFormattedTextField();
	MaskFormatter childCareMask = createFormatter("####");
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmStartNewForm = new JMenuItem("Start New Form");
	private final JMenuItem mntmClose = new JMenuItem("Close");
	
	private final JLabel lblCommute = new JLabel("Commute:");
	private final JFormattedTextField commuteTF = new JFormattedTextField();
	MaskFormatter commuteMask = createFormatter("###");
	private final JLabel lblLoansInsurance = new JLabel("Loans + Insurance:");
	private final JFormattedTextField loansInsuranceTF = new JFormattedTextField();
	MaskFormatter loansInsuranceMask = createFormatter("####");
	private final JComboBox commuteComboBox = new JComboBox();
	private final JLabel lblTotalIncome = new JLabel("Total Income:");
	private final JLabel totalIncomeDisplay = new JLabel("$0.0");
	private final JLabel totalExpenseDisplay = new JLabel("$0.0");
	private final JLabel lblTotalExpenses = new JLabel("Total Expenses:");
	private final JLabel lblNet = new JLabel("NET:");
	private final JLabel netIncomeDisplay = new JLabel("$0.0");
	private final JPanel ChildInfo = new JPanel();
	private final JLabel lblChild = new JLabel("Child:");
	private final JComboBox childNumberComboBox = new JComboBox();
	private final JLabel lblChildFirstName = new JLabel("First Name:");
	private final JTextField childFirstNameTF = new JTextField();
	private final JLabel lblGender = new JLabel("Gender:");
	private final JLabel lblDOB = new JLabel("Date of Birth:");
	private final JLabel lblAge = new JLabel("Age:");
	private final JLabel lblClotheSize = new JLabel("Clothing Size:");
	private final JLabel lblShoeSize = new JLabel("Shoe Size:");
	private final JLabel lblCoatSize = new JLabel("Coat Size:");
	private final JLabel lblGamingSystem = new JLabel("Gaming System:");
	private final JFormattedTextField dobTF = new JFormattedTextField();
	MaskFormatter dobMask = createFormatter("##/##/####");
	private final JFormattedTextField ageTF = new JFormattedTextField();
	MaskFormatter ageMask = createFormatter("##");
	private final JComboBox clotheComboBox = new JComboBox();
	private final JFormattedTextField shoeTF = new JFormattedTextField();
	MaskFormatter shoeMask = createFormatter("##");
	private final JFormattedTextField coatTF = new JFormattedTextField();
	MaskFormatter coatMask = createFormatter("U");
	private final JComboBox genderComboBox = new JComboBox();
	private final JComboBox gameConsoleComboBox = new JComboBox();
	private final JLabel lblInterests = new JLabel("Interests");
	private final JScrollPane scrollPane = new JScrollPane();
	private final JList interestList = new JList();
	
	private int firstRun=0; //A boolean to see if you have finished the information
	private double income=0;
	private double expenses=0;
	private double netMoney=0;
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenu mnFinancials = new JMenu("Financials");
	private final JMenuItem mnChildInformation = new JMenuItem("Child Information");
	private final JMenuItem mnInformation = new JMenuItem("Information");
	private final JCheckBoxMenuItem mntmDisableDialogs = new JCheckBoxMenuItem("Disable Dialogs");
	
	
	
	//** Adds objects for each child
	private String name1, name2, name3, name4, name5, name6;
	private int gender1=0, gender2=0, gender3=0, gender4=0, gender5=0, gender6=0;
	private String birthday1, birthday2, birthday3, birthday4, birthday5, birthday6;
	private String age1, age2, age3, age4, age5, age6;
	private int clothing1=0, clothing2=0, clothing3=0, clothing4=0, clothing5=0, clothing6=0;
	private String shoe1, shoe2, shoe3, shoe4, shoe5, shoe6;
	private String coat1, coat2, coat3, coat4, coat5, coat6;
	private int game1=0, game2=0, game3=0, game4=0, game5=0, game6=0;
	private int [] interest1, interest2, interest3, interest4, interest5, interest6;
	
	
	private final JSpinner child18PlusSpinner = new JSpinner();
	private final JMenuItem mntmIncome = new JMenuItem("Income");
	private final JMenuItem mntmExpenses = new JMenuItem("Expenses");
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LynchProject1Frame frame = new LynchProject1Frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private MaskFormatter createFormatter(String string) {
		MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(string);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	     return formatter;
	}
	/**
	 * Create the frame.
	 */
	public LynchProject1Frame() {
		coatTF.setToolTipText("<html>\n<body>\nEnter your coat size.\n</body>\n</html>");
		coatTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		coatTF.setBounds(129, 214, 25, 26);
		coatTF.setColumns(10);
		shoeTF.setToolTipText("<html>\n<body>\nEnter your shoe size.\n</body>\n</html>");
		shoeTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		shoeTF.setBounds(129, 186, 25, 26);
		shoeTF.setColumns(10);
		clotheComboBox.setModel(new DefaultComboBoxModel(new String[] {"XS", "S", "M", "L", "XL", "2X"}));
		clotheComboBox.setToolTipText("<html>\n<body>\nSelect your child's clothing size.\n</body>\n</html>");
		clotheComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		clotheComboBox.setBounds(129, 158, 82, 26);
		ageTF.setToolTipText("<html>\n<body>\nEnter your child's age.\n</body>\n</html>");
		ageTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		ageTF.setBounds(129, 130, 25, 26);
		ageTF.setColumns(10);
		dobTF.setToolTipText("<html>\n<body>\nEnter your child's date of birth.\n</body>\n</html>");
		dobTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		dobTF.setBounds(129, 102, 82, 26);
		dobTF.setColumns(10);
		childFirstNameTF.setToolTipText("<html>\n<body>\nEnter your child's first name.\n</body>\n</html>");
		childFirstNameTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		childFirstNameTF.setBounds(129, 47, 130, 26);
		childFirstNameTF.setColumns(10);
		loansInsuranceTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for loans and insurance.\n</body>\n</html>");
		loansInsuranceTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_loansInsuranceTF_focusLost(e);
			}
		});
		loansInsuranceTF.setHorizontalAlignment(SwingConstants.RIGHT);
		loansInsuranceTF.setForeground(Color.RED);
		loansInsuranceTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		loansInsuranceTF.setBounds(455, 165, 130, 26);
		loansInsuranceTF.setColumns(10);
		commuteTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for you commute.\n</body>\n</html>");
		commuteTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_commuteTF_focusLost(e);
			}
		});
		commuteTF.setHorizontalAlignment(SwingConstants.RIGHT);
		commuteTF.setForeground(Color.RED);
		commuteTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		commuteTF.setBounds(486, 137, 99, 26);
		commuteTF.setColumns(10);
		childCareExpenseTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for child care.\n</body>\n</html>");
		childCareExpenseTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_childCareExpenseTF_focusLost(e);
			}
		});
		childCareExpenseTF.setHorizontalAlignment(SwingConstants.RIGHT);
		childCareExpenseTF.setForeground(Color.RED);
		childCareExpenseTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		childCareExpenseTF.setBounds(455, 109, 130, 26);
		childCareExpenseTF.setColumns(10);
		phoneTVTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for phone and TV.\n</body>\n</html>");
		phoneTVTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_phoneTVTF_focusLost(e);
			}
		});
		phoneTVTF.setHorizontalAlignment(SwingConstants.RIGHT);
		phoneTVTF.setForeground(Color.RED);
		phoneTVTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		phoneTVTF.setBounds(455, 81, 130, 26);
		phoneTVTF.setColumns(10);
		gasWaterTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for gas and water.\n</body>\n</html>");
		gasWaterTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_gasWaterTF_focusLost(e);
			}
		});
		gasWaterTF.setHorizontalAlignment(SwingConstants.RIGHT);
		gasWaterTF.setForeground(Color.RED);
		gasWaterTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		gasWaterTF.setBounds(455, 53, 130, 26);
		gasWaterTF.setColumns(10);
		rentTF.setToolTipText("<html>\n<body>\nEnter your total amount you pay for rent/morgage.\n</body>\n</html>");
		rentTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_rentTF_focusLost(e);
			}
		});
		rentTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		rentTF.setForeground(Color.RED);
		rentTF.setHorizontalAlignment(SwingConstants.RIGHT);
		rentTF.setBounds(486, 25, 99, 26);
		rentTF.setColumns(10);
		taxCreditTF.setToolTipText("<html>\n<body>\nEnter your total amount of child tax credit.\n</body>\n</html>");
		taxCreditTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_taxCreditTF_focusLost(e);
			}
		});
		taxCreditTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		taxCreditTF.setForeground(new Color(0, 128, 0));
		taxCreditTF.setHorizontalAlignment(SwingConstants.RIGHT);
		taxCreditTF.setBounds(152, 166, 130, 26);
		taxCreditTF.setColumns(10);
		pensionTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_pensionTF_focusLost(e);
			}
		});
		pensionTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		pensionTF.setForeground(new Color(0, 128, 0));
		pensionTF.setHorizontalAlignment(SwingConstants.RIGHT);
		pensionTF.setBounds(152, 138, 130, 26);
		pensionTF.setColumns(10);
		disabilityTF.setToolTipText("<html>\n<body>\nEnter your total amount of E.I./Disability support.\n</body>\n</html>");
		disabilityTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_disabilityTF_focusLost(e);
			}
		});
		disabilityTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		disabilityTF.setForeground(new Color(0, 128, 0));
		disabilityTF.setHorizontalAlignment(SwingConstants.RIGHT);
		disabilityTF.setBounds(152, 110, 130, 26);
		disabilityTF.setColumns(10);
		ontarioWorksTF.setToolTipText("<html>\n<body>\nEnter your total amount of Ontario Works.<br>\n<br>\nHow much money did you recieve from Ontario Works?\n</body>\n</html>");
		ontarioWorksTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_ontarioWorksTF_focusLost(e);
			}
		});
		ontarioWorksTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		ontarioWorksTF.setForeground(new Color(0, 128, 0));
		ontarioWorksTF.setHorizontalAlignment(SwingConstants.RIGHT);
		ontarioWorksTF.setBounds(152, 82, 130, 26);
		ontarioWorksTF.setColumns(10);
		supportIncomeTF.setToolTipText("<html>\n<body>\nEnter your total amount of child support.<br>\n<br>\nHow much money did you recieve for child support?\n</body>\n</html>");
		supportIncomeTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_supportIncomeTF_focusLost(e);
			}
		});
		supportIncomeTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		supportIncomeTF.setForeground(new Color(0, 128, 0));
		supportIncomeTF.setHorizontalAlignment(SwingConstants.RIGHT);
		supportIncomeTF.setBounds(152, 54, 130, 26);
		supportIncomeTF.setColumns(10);
		totalIncomeTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_totalIncomeTF_focusLost(e);
			}
		});
		totalIncomeTF.setToolTipText("<html>\n<body>\nEnter your total income from your employment.<br>\n<br>\nIf you have more than one job, add the income together.\n</body>\n</html>");
		totalIncomeTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		totalIncomeTF.setHorizontalAlignment(SwingConstants.RIGHT);
		totalIncomeTF.setForeground(new Color(0, 128, 0));
		totalIncomeTF.setBounds(152, 27, 130, 26);
		totalIncomeTF.setColumns(10);
		emailTF.setToolTipText("<html>\n<body>\nPlease enter your email address.\n</body>\n</html>");
		emailTF.setBounds(78, 192, 130, 26);
		emailTF.setColumns(10);
		telephoneTF.setToolTipText("<html>\n<body>\nEnter your telephone number.\n</body>\n</html>");
		telephoneTF.setBounds(78, 164, 130, 26);
		telephoneTF.setColumns(10);
		cityOtherTF.setBounds(223, 91, 148, 26);
		cityOtherTF.setColumns(10);
		zipTF.setToolTipText("<html>\n<body>\nEnter your zip code for your town.\n</body>\n</html>");
		zipTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		zipTF.setBounds(78, 125, 83, 26);
		zipTF.setColumns(10);
		addressTF.setToolTipText("<html>\n<body>\nYour mailing address<br>\n(House # and Street Address)\n</body>\n</html>");
		addressTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		addressTF.setBounds(78, 66, 293, 26);
		addressTF.setColumns(10);
		lastNameTF.setToolTipText("<html>\n<body>\nEnter your last name.\n</body>\n</html>");
		lastNameTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lastNameTF.setBounds(78, 29, 130, 26);
		lastNameTF.setColumns(10);
		firstNameTF.setToolTipText("<html>\n<body>\nEnter your first name.\n</body>\n</html>");
		firstNameTF.setFont(new Font("Helvetica", Font.PLAIN, 13));
		firstNameTF.setBounds(78, 5, 130, 26);
		firstNameTF.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Lynch Project 1");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 624, 418);
		
		setJMenuBar(menuBar);
		
		menuBar.add(mnFile);
		mntmStartNewForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmStartNewForm_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmStartNewForm);
		mntmClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmClose_actionPerformed(e);
			}
		});
		mntmDisableDialogs.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_mntmDisableDialogs_stateChanged(e);
			}
		});
		
		mnFile.add(mntmDisableDialogs);
		
		mnFile.add(mntmClose);
		
		menuBar.add(mnHelp);
		mnInformation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mnInformation_actionPerformed(e);
			}
		});
		
		mnHelp.add(mnInformation);
		
		mnHelp.add(mnFinancials);
		mntmIncome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmIncome_actionPerformed(e);
			}
		});
		
		mnFinancials.add(mntmIncome);
		mntmExpenses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmExpenses_actionPerformed(e);
			}
		});
		
		mnFinancials.add(mntmExpenses);
		mnChildInformation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mnChildInformation_actionPerformed(e);
			}
		});
		
		mnHelp.add(mnChildInformation);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_tabbedPane_stateChanged(e);
			}
		});
		tabbedPane.setBounds(6, 6, 612, 362);
		
		contentPane.add(tabbedPane);
		
		
		tabbedPane.addTab("Information", null, Information, null);
		Information.setLayout(null);
		lblFirstName.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblFirstName.setBounds(6, 6, 76, 22);
		
		Information.add(lblFirstName);
		
		Information.add(firstNameTF);
		lblLastName.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblLastName.setBounds(6, 32, 76, 22);
		
		Information.add(lblLastName);
		
		Information.add(lastNameTF);
		lblAddress.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblAddress.setBounds(6, 72, 61, 16);
		
		Information.add(lblAddress);
		
		Information.add(addressTF);
		lblTown.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblTown.setBounds(6, 97, 34, 16);
		
		Information.add(lblTown);
		cityComboBox.setToolTipText("<html>\n<body>\nSelect one of the available cities.<br>\n<br>\nIf your city is not listed, select other and type it in the box.\n</body>\n</html>");
		cityComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_cityComboBox_actionPerformed(e);
			}
		});
		cityComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		cityComboBox.setModel(new DefaultComboBoxModel(new String[] {"-", "Auroa", "Bradford", "East Gwillmbury", "Georgina/Keswick", "Holland Landing", "Markham", "Mount Albert", "Newmarket", "Queensville", "Richmond Hill", "Schomberg", "Sharon", "Stouffville", "Vaughan", "Other"}));
		cityComboBox.setBounds(78, 93, 148, 27);
		
		Information.add(cityComboBox);
		lblZipCode.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblZipCode.setBounds(6, 129, 61, 16);
		
		
		Information.add(lblZipCode);
		
		zipMask.setPlaceholderCharacter('#');
		zipMask.install(zipTF);
		Information.add(zipTF);
		
		Information.add(cityOtherTF);
		lblTelephone.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblTelephone.setBounds(6, 170, 64, 16);
		
		Information.add(lblTelephone);
		
		phoneMask.setPlaceholderCharacter('#');
		phoneMask.install(telephoneTF);
		Information.add(telephoneTF);
		lblEmail.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblEmail.setBounds(6, 198, 61, 16);
		
		Information.add(lblEmail);
		
		Information.add(emailTF);
		lblAdultNum.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblAdultNum.setBounds(6, 251, 76, 16);
		
		Information.add(lblAdultNum);
		adultSpinner.setModel(new SpinnerNumberModel(1, 0, 2, 1));
		adultSpinner.setToolTipText("<html>\n<body>\nHow many adults are in your family?\n</body>\n</html>");
		adultSpinner.setBounds(78, 245, 33, 26);
		
		Information.add(adultSpinner);
		lblChildren18.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildren18.setBounds(142, 250, 110, 16);
		
		Information.add(lblChildren18);
		lblChildren17.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildren17.setBounds(297, 250, 110, 16);
		
		Information.add(lblChildren17);
		child017Spinner.setModel(new SpinnerNumberModel(1, 0, 6, 1));
		child017Spinner.setToolTipText("<html>\n<body>\nHow man children under 18 do you have?\n</body>\n</html>");
		child017Spinner.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_child017Spinner_stateChanged(e);
			}
		});
		child017Spinner.setBounds(406, 245, 33, 26);
		
		Information.add(child017Spinner);
		child18PlusSpinner.setModel(new SpinnerNumberModel(0, 0, 6, 1));
		child18PlusSpinner.setToolTipText("<html>\n<body>\nHow many adults are in your family?\n</body>\n</html>");
		child18PlusSpinner.setBounds(252, 245, 33, 26);
		
		Information.add(child18PlusSpinner);
		Financials.setToolTipText("<html>\n<body>\nEnter Your financial information\n</body>\n</html>");
		
		tabbedPane.addTab("Financials", null, Financials, null);
		Financials.setLayout(null);
		lblIncome.setFont(new Font("Helvetica", Font.PLAIN, 18));
		lblIncome.setBounds(119, 6, 59, 16);
		
		Financials.add(lblIncome);
		separator.setForeground(Color.DARK_GRAY);
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(294, 6, 12, 200);
		
		Financials.add(separator);
		lblExpenses.setFont(new Font("Helvetica", Font.PLAIN, 18));
		lblExpenses.setBounds(411, 6, 79, 16);
		
		Financials.add(lblExpenses);
		lblEmployment.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblEmployment.setBounds(6, 31, 134, 16);
		
		Financials.add(lblEmployment);
		
		totalIncomeMask.setPlaceholderCharacter('0');
		totalIncomeMask.install(totalIncomeTF);
		Financials.add(totalIncomeTF);
		lblChildSupport.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildSupport.setBounds(6, 59, 149, 16);
		
		Financials.add(lblChildSupport);
		
		supportIncomeMask.setPlaceholderCharacter('0');
		supportIncomeMask.install(supportIncomeTF);
		Financials.add(supportIncomeTF);
		ontarioWorksIncome.setFont(new Font("Helvetica", Font.PLAIN, 13));
		ontarioWorksIncome.setBounds(6, 87, 134, 16);
		
		Financials.add(ontarioWorksIncome);
		
		ontarioWorkIncomeMask.setPlaceholderCharacter('0');
		ontarioWorkIncomeMask.install(ontarioWorksTF);
		Financials.add(ontarioWorksTF);
		lblDisability.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblDisability.setBounds(6, 115, 134, 16);
		
		Financials.add(lblDisability);
		
		disabilityMask.setPlaceholderCharacter('0');
		disabilityMask.install(disabilityTF);
		Financials.add(disabilityTF);
		lblPension.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblPension.setBounds(6, 143, 134, 16);
		
		Financials.add(lblPension);
		
		pensionMask.setPlaceholderCharacter('0');
		pensionMask.install(pensionTF);
		Financials.add(pensionTF);
		lblChildTaxCredit.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildTaxCredit.setBounds(6, 171, 134, 16);
		
		Financials.add(lblChildTaxCredit);
		
		taxCreditMask.setPlaceholderCharacter('0');
		taxCreditMask.install(taxCreditTF);
		Financials.add(taxCreditTF);
		housePaymentComboBox.setToolTipText("<html>\n<body>\nSelect whether you rent your home, or pay a morgage.\n</body>\n</html>");
		housePaymentComboBox.setModel(new DefaultComboBoxModel(new String[] {"Rent", "Mortgage"}));
		housePaymentComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		housePaymentComboBox.setBounds(374, 26, 81, 27);
		
		Financials.add(housePaymentComboBox);
		lblHome.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblHome.setBounds(321, 30, 61, 16);
		
		Financials.add(lblHome);
		
		rentMask.setPlaceholderCharacter('0');
		rentMask.install(rentTF);
		Financials.add(rentTF);
		lblGasWater.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblGasWater.setBounds(321, 59, 134, 16);
		
		Financials.add(lblGasWater);
		
		gasWaterMask.setPlaceholderCharacter('0');
		gasWaterMask.install(gasWaterTF);
		Financials.add(gasWaterTF);
		lblPhoneTv.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblPhoneTv.setBounds(321, 87, 134, 16);
		
		Financials.add(lblPhoneTv);
		
		phoneTVMask.setPlaceholderCharacter('0');
		phoneTVMask.install(phoneTVTF);
		Financials.add(phoneTVTF);
		lblChildCare.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildCare.setBounds(321, 115, 134, 16);
		
		Financials.add(lblChildCare);
		
		childCareMask.setPlaceholderCharacter('0');
		childCareMask.install(childCareExpenseTF);
		Financials.add(childCareExpenseTF);
		lblCommute.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblCommute.setBounds(321, 143, 61, 16);
		
		Financials.add(lblCommute);
		
		commuteMask.setPlaceholderCharacter('0');
		commuteMask.install(commuteTF);
		Financials.add(commuteTF);
		lblLoansInsurance.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblLoansInsurance.setBounds(321, 171, 134, 16);
		
		Financials.add(lblLoansInsurance);
		
		loansInsuranceMask.setPlaceholderCharacter('0');
		loansInsuranceMask.install(loansInsuranceTF);
		Financials.add(loansInsuranceTF);
		commuteComboBox.setToolTipText("<html>\n<body>\nEnter whether you take transit or your own car (and pay for gas) to work.\n</body>\n</html>");
		commuteComboBox.setModel(new DefaultComboBoxModel(new String[] {"Transit", "Gas"}));
		commuteComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		commuteComboBox.setBounds(374, 138, 81, 27);
		
		Financials.add(commuteComboBox);
		lblTotalIncome.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblTotalIncome.setBounds(50, 237, 90, 16);
		
		Financials.add(lblTotalIncome);
		totalIncomeDisplay.setForeground(new Color(0, 128, 0));
		totalIncomeDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		totalIncomeDisplay.setFont(new Font("Helvetica", Font.PLAIN, 13));
		totalIncomeDisplay.setBounds(152, 237, 61, 16);
		
		Financials.add(totalIncomeDisplay);
		totalExpenseDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		totalExpenseDisplay.setForeground(Color.RED);
		totalExpenseDisplay.setFont(new Font("Helvetica", Font.PLAIN, 13));
		totalExpenseDisplay.setBounds(429, 237, 61, 16);
		
		Financials.add(totalExpenseDisplay);
		lblTotalExpenses.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblTotalExpenses.setBounds(327, 237, 99, 16);
		
		Financials.add(lblTotalExpenses);
		lblNet.setBounds(248, 269, 39, 16);
		
		Financials.add(lblNet);
		netIncomeDisplay.setBounds(297, 269, 61, 16);
		
		Financials.add(netIncomeDisplay);
		Financials.setFocusCycleRoot(true);
		Financials.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{totalIncomeTF, supportIncomeTF, ontarioWorksTF, disabilityTF, pensionTF, taxCreditTF, housePaymentComboBox, rentTF, gasWaterTF, phoneTVTF, childCareExpenseTF, commuteComboBox, commuteTF, loansInsuranceTF}));
		
		tabbedPane.addTab("Child Information", null, ChildInfo, null);
		ChildInfo.setLayout(null);
		lblChild.setFont(new Font("Helvetica", Font.PLAIN, 17));
		lblChild.setBounds(61, 6, 52, 16);
		
		ChildInfo.add(lblChild);
		childNumberComboBox.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				do_childNumberComboBox_focusGained(e);
			}
		});
		childNumberComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_childNumberComboBox_actionPerformed(e);
			}
		});
		childNumberComboBox.setToolTipText("<html>\n<body>\nSelect a child.\n</body>\n</html>");
		childNumberComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1"}));
		childNumberComboBox.setBounds(112, 1, 66, 27);
		
		ChildInfo.add(childNumberComboBox);
		lblChildFirstName.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblChildFirstName.setBounds(40, 52, 77, 16);
		
		ChildInfo.add(lblChildFirstName);
		
		ChildInfo.add(childFirstNameTF);
		lblGender.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblGender.setBounds(40, 80, 77, 16);
		
		ChildInfo.add(lblGender);
		lblDOB.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblDOB.setBounds(40, 108, 96, 16);
		
		ChildInfo.add(lblDOB);
		lblAge.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblAge.setBounds(40, 136, 77, 16);
		
		ChildInfo.add(lblAge);
		lblClotheSize.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblClotheSize.setBounds(40, 164, 96, 16);
		
		ChildInfo.add(lblClotheSize);
		lblShoeSize.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblShoeSize.setBounds(40, 192, 77, 16);
		
		ChildInfo.add(lblShoeSize);
		lblCoatSize.setFont(new Font("Helvetica", Font.PLAIN, 13));
		lblCoatSize.setBounds(40, 220, 77, 16);
		
		ChildInfo.add(lblCoatSize);
		lblGamingSystem.setFont(new Font("Helvetica", Font.PLAIN, 12));
		lblGamingSystem.setBounds(40, 248, 108, 16);
		
		ChildInfo.add(lblGamingSystem);
		
		dobMask.setPlaceholderCharacter('#');
		dobMask.install(dobTF);
		ChildInfo.add(dobTF);
		
		ageMask.setPlaceholderCharacter('#');
		ageMask.install(ageTF);
		ChildInfo.add(ageTF);
		
		ChildInfo.add(clotheComboBox);
		
		shoeMask.setPlaceholderCharacter('#');
		shoeMask.install(shoeTF);
		ChildInfo.add(shoeTF);
		
		coatMask.setPlaceholderCharacter('*');
		coatMask.install(coatTF);
		ChildInfo.add(coatTF);
		genderComboBox.setToolTipText("<html>\n<body>\nWhat is your childs gender?\n</body>\n</html>");
		genderComboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		genderComboBox.setBounds(129, 75, 96, 27);
		
		ChildInfo.add(genderComboBox);
		gameConsoleComboBox.setToolTipText("<html>\n<body>\nWhat gaming system does your child have?\n</body>\n</html>");
		gameConsoleComboBox.setModel(new DefaultComboBoxModel(new String[] {"-", "Xbox One", "Xbox 360", "Playstation 4", "Playstation 3", "PSP", "Computer", "Wii U", "Wii ", "Nintendo DS", "None"}));
		gameConsoleComboBox.setFont(new Font("Helvetica", Font.PLAIN, 13));
		gameConsoleComboBox.setBounds(129, 243, 130, 27);
		
		ChildInfo.add(gameConsoleComboBox);
		lblInterests.setBounds(374, 51, 61, 16);
		
		ChildInfo.add(lblInterests);
		scrollPane.setBounds(394, 77, 130, 88);
		
		ChildInfo.add(scrollPane);
		interestList.setToolTipText("<html>\n<body>\nSelect your childs intrest.<br>\n<br>\nTo select more than one item<br>\nhold down the CONTROL key.\n</body>\n</html>");
		interestList.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heros", "Cars/Trucks", "Planes/Trains", "Music", "Construction", "Lego/Duplo", "Outdoors", "Dolls", "Sports", "Other"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		scrollPane.setViewportView(interestList);
		cityOtherTF.setVisible(false);
	}
	
	
	
	
	//EXTRA CODE
	
	//Start new form Code
	protected void do_mntmStartNewForm_actionPerformed(ActionEvent e) {
		dispose();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LynchProject1Frame frame = new LynchProject1Frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//Changes the Child Combo Box in Child info for how many kids you have
	protected void do_child017Spinner_stateChanged(ChangeEvent e) {
		if(Integer.parseInt(child017Spinner.getValue()+"")==0){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {""}));
			childFirstNameTF.setEnabled(false);
			genderComboBox.setEnabled(false);
			dobTF.setEnabled(false);
			ageTF.setEnabled(false);
			clotheComboBox.setEnabled(false);
			shoeTF.setEnabled(false);
			coatTF.setEnabled(false);
			gameConsoleComboBox.setEnabled(false);
			interestList.setEnabled(false);
		}
		else{
			childFirstNameTF.setEnabled(true);
			genderComboBox.setEnabled(true);
			dobTF.setEnabled(true);
			ageTF.setEnabled(true);
			clotheComboBox.setEnabled(true);
			shoeTF.setEnabled(true);
			coatTF.setEnabled(true);
			gameConsoleComboBox.setEnabled(true);
			interestList.setEnabled(true);
		}
		if(Integer.parseInt(child017Spinner.getValue()+"")==1){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1"}));
		}
		else if(Integer.parseInt(child017Spinner.getValue()+"")==2){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1","2"}));
		}
		else if(Integer.parseInt(child017Spinner.getValue()+"")==3){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1","2","3"}));
		}
		else if(Integer.parseInt(child017Spinner.getValue()+"")==4){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1","2","3","4"}));
		}
		else if(Integer.parseInt(child017Spinner.getValue()+"")==5){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1","2","3","4","5"}));
		}
		else if(Integer.parseInt(child017Spinner.getValue()+"")==6){
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"1","2","3","4","5","6"}));
		}
		else{
			childNumberComboBox.setModel(new DefaultComboBoxModel(new String[] {"NA"}));
		}
	}
	
	//Enables the 'Other Box' when you select the 'Other' City from the Combo Box
	protected void do_cityComboBox_actionPerformed(ActionEvent e) {
		if(cityComboBox.getSelectedItem().toString()=="Other"){
			cityOtherTF.setVisible(true);
		}
		if(cityComboBox.getSelectedItem().toString()!="Other"){
			cityOtherTF.setVisible(false);
		}
	}
	//Adds a dialog to make sure all information is correct when focus is lost
	
//***Following are functions to update Net income
	protected void do_totalIncomeTF_focusLost(FocusEvent e) {
		income=Double.parseDouble(totalIncomeTF.getText()+"")+Double.parseDouble(supportIncomeTF.getText()+"")+Double.parseDouble(ontarioWorksTF.getText()+"")+Double.parseDouble(disabilityTF.getText()+"")+Double.parseDouble(pensionTF.getText()+"")+Double.parseDouble(taxCreditTF.getText()+"");
		expenses=Double.parseDouble(rentTF.getText()+"")+Double.parseDouble(gasWaterTF.getText()+"")+Double.parseDouble(phoneTVTF.getText()+"")+Double.parseDouble(childCareExpenseTF.getText()+"")+Double.parseDouble(commuteTF.getText()+"")+Double.parseDouble(loansInsuranceTF.getText()+"");
		netMoney=income-expenses;
		netIncomeDisplay.setText("$"+netMoney);
		totalExpenseDisplay.setText("$"+expenses);
		totalIncomeDisplay.setText("$"+income);
	}
	protected void do_supportIncomeTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_ontarioWorksTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_disabilityTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_pensionTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_taxCreditTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_rentTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_gasWaterTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_phoneTVTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_childCareExpenseTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_commuteTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
	protected void do_loansInsuranceTF_focusLost(FocusEvent e) {
		do_totalIncomeTF_focusLost(e);
	}
//**End Net Income Functions
	//Close function
	protected void do_mntmClose_actionPerformed(ActionEvent e) {
		System.exit(0);
	}
	
	//Code to save child information and add it back
	protected void do_childNumberComboBox_actionPerformed(ActionEvent e) {
		if(childNumberComboBox.getSelectedIndex()==0){
			if(name1!=null)
				childFirstNameTF.setText(name1);
			genderComboBox.setSelectedIndex(gender1);
			if(birthday1!=null)
				dobTF.setText(birthday1);
			if(age1!=null)
				ageTF.setText(age1);
			clotheComboBox.setSelectedIndex(clothing1);
			if(shoe1!=null)
				shoeTF.setText(shoe1);
			if(coat1!=null)
				coatTF.setText(coat1);
			gameConsoleComboBox.setSelectedIndex(game1);
			if(interest1!=null)
				interestList.setSelectedIndices(interest1);
		}
		else if(childNumberComboBox.getSelectedIndex()==1){
			if(name2!=null)
				childFirstNameTF.setText(name2);
			genderComboBox.setSelectedIndex(gender2);
			if(birthday2!=null)
				dobTF.setText(birthday2);
			if(age2!=null)
				ageTF.setText(age2);
			clotheComboBox.setSelectedIndex(clothing2);
			if(shoe2!=null)
				shoeTF.setText(shoe2);
			if(coat2!=null)
				coatTF.setText(coat2);
			gameConsoleComboBox.setSelectedIndex(game2);
			if(interest2!=null)
				interestList.setSelectedIndices(interest2);
		}
		else if(childNumberComboBox.getSelectedIndex()==2){
			if(name3!=null)
				childFirstNameTF.setText(name3);
			genderComboBox.setSelectedIndex(gender3);
			if(birthday3!=null)
				dobTF.setText(birthday3);
			if(age3!=null)
				ageTF.setText(age3);
			clotheComboBox.setSelectedIndex(clothing3);
			if(shoe3!=null)
				shoeTF.setText(shoe3);
			if(coat3!=null)
				coatTF.setText(coat3);
			gameConsoleComboBox.setSelectedIndex(game3);
			if(interest3!=null)
				interestList.setSelectedIndices(interest3);
		}
		else if(childNumberComboBox.getSelectedIndex()==3){
			if(name4!=null)
				childFirstNameTF.setText(name4);
			genderComboBox.setSelectedIndex(gender4);
			if(birthday4!=null)
				dobTF.setText(birthday4);
			if(age4!=null)
				ageTF.setText(age4);
			clotheComboBox.setSelectedIndex(clothing4);
			if(shoe4!=null)
				shoeTF.setText(shoe4);
			if(coat4!=null)
				coatTF.setText(coat4);
			gameConsoleComboBox.setSelectedIndex(game4);
			if(interest4!=null)
				interestList.setSelectedIndices(interest4);
		}
		else if(childNumberComboBox.getSelectedIndex()==4){
			if(name5!=null)
				childFirstNameTF.setText(name5);
			genderComboBox.setSelectedIndex(gender5);
			if(birthday5!=null)
				dobTF.setText(birthday5);
			if(age5!=null)
				ageTF.setText(age5);
			clotheComboBox.setSelectedIndex(clothing5);
			if(shoe5!=null)
				shoeTF.setText(shoe5);
			if(coat5!=null)
				coatTF.setText(coat5);
			gameConsoleComboBox.setSelectedIndex(game5);
			if(interest5!=null)
				interestList.setSelectedIndices(interest5);
		}
		else if(childNumberComboBox.getSelectedIndex()==5){
			if(name6!=null)
				childFirstNameTF.setText(name6);
			genderComboBox.setSelectedIndex(gender6);
			if(birthday6!=null)
				dobTF.setText(birthday6);
			if(age6!=null)
				ageTF.setText(age6);
			clotheComboBox.setSelectedIndex(clothing6);
			if(shoe6!=null)
				shoeTF.setText(shoe6);
			if(coat6!=null)
				coatTF.setText(coat6);
			gameConsoleComboBox.setSelectedIndex(game6);
			if(interest6!=null)
				interestList.setSelectedIndices(interest6);
		}
	}
	
	//Sets the code for when you go back to a child you already filled out
	protected void do_childNumberComboBox_focusGained(FocusEvent e) {
		if(Integer.parseInt(child017Spinner.getValue()+"")==0){
			JOptionPane.showMessageDialog(this,"You don't have any Children!");
		}
		if(childNumberComboBox.getSelectedIndex()==0){
			name1=childFirstNameTF.getText();
			gender1=genderComboBox.getSelectedIndex();
			birthday1=dobTF.getText();
			age1=ageTF.getText();
			clothing1=clotheComboBox.getSelectedIndex();
			shoe1=shoeTF.getText();
			coat1=coatTF.getText();
			game1=gameConsoleComboBox.getSelectedIndex();
			interest1=interestList.getSelectedIndices(); 
		}
		else if(childNumberComboBox.getSelectedIndex()==1){
			name2=childFirstNameTF.getText();
			gender2=genderComboBox.getSelectedIndex();
			birthday2=dobTF.getText();
			age2=ageTF.getText();
			clothing2=clotheComboBox.getSelectedIndex();
			shoe2=shoeTF.getText();
			coat2=coatTF.getText();
			game2=gameConsoleComboBox.getSelectedIndex();
			interest2=interestList.getSelectedIndices(); 
		}
		else if(childNumberComboBox.getSelectedIndex()==2){
			name3=childFirstNameTF.getText();
			gender3=genderComboBox.getSelectedIndex();
			birthday3=dobTF.getText();
			age3=ageTF.getText();
			clothing3=clotheComboBox.getSelectedIndex();
			shoe3=shoeTF.getText();
			coat3=coatTF.getText();
			game3=gameConsoleComboBox.getSelectedIndex();
			interest3=interestList.getSelectedIndices(); 
		}
		else if(childNumberComboBox.getSelectedIndex()==3){
			name4=childFirstNameTF.getText();
			gender4=genderComboBox.getSelectedIndex();
			birthday4=dobTF.getText();
			age4=ageTF.getText();
			clothing4=clotheComboBox.getSelectedIndex();
			shoe4=shoeTF.getText();
			coat4=coatTF.getText();
			game4=gameConsoleComboBox.getSelectedIndex();
			interest4=interestList.getSelectedIndices(); 
		}
		else if(childNumberComboBox.getSelectedIndex()==4){
			name5=childFirstNameTF.getText();
			gender5=genderComboBox.getSelectedIndex();
			birthday5=dobTF.getText();
			age5=ageTF.getText();
			clothing5=clotheComboBox.getSelectedIndex();
			shoe5=shoeTF.getText();
			coat5=coatTF.getText();
			game5=gameConsoleComboBox.getSelectedIndex();
			interest5=interestList.getSelectedIndices(); 
		}
		else if(childNumberComboBox.getSelectedIndex()==5){
			name6=childFirstNameTF.getText();
			gender6=genderComboBox.getSelectedIndex();
			birthday6=dobTF.getText();
			age6=ageTF.getText();
			clothing6=clotheComboBox.getSelectedIndex();
			shoe6=shoeTF.getText();
			coat6=coatTF.getText();
			game6=gameConsoleComboBox.getSelectedIndex();
			interest6=interestList.getSelectedIndices(); 
		}
		
	}
	
//Help Menus
	protected void do_mnInformation_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this,
				"<html><h2><center>Information</center</h2><br>"
				+ "<b>First Name: </b>Enter your legal first name.<br>"
				+ "<b>Last Name: </b>Enter your legal last name.<br>"
				+ "<b>Address: </b>Enter your street number and address.<br>"
				+ "<b>City: </b>Please select a city from the list (if your city isn't listed, please select other).<br>"
				+ "<b>Telephone: </b>Please enter your full phone number.<br>"
				+ "<b>Email: </b>Enter your email address.<br>"
				+ "<b># of Adults: </b>How many adults live in your house?<br>"
				+ "<b># of Children 18+: </b>How many children that are older than 18 live in your house?<br>"
				+ "<b># of Children 0-17: </b>How many children that are younger than 18 live in your house?</html>","Information Help", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mntmIncome_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this,
				"<html><h2><center>Financials - Income</center</h2><br>"
				+ "<b>Employment: </b>Enter your total income from employment.<br>"
				+ "<b>Child/Spousal Support: </b>Enter your total child/spousal support.<br>"
				+ "<b>Ontario Works: </b>Enter your total income from Ontario Works.<br>"
				+ "<b>E.I. or Disability: </b>Enter your total income from E.I. or Disability.<br>"
				+ "<b>Pension: </b>Enter your total income from your pension.<br>"
				+ "<b>Child Tax Credit: </b>Enter your total child tax credit.</html>","Financial Help", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mntmExpenses_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this,
				"<html><h2><center>Financials - Expenses</center</h2><br>"
				+ "<b>Home: </b>Select whether you rent or own (morgage) your home, then enter your total monthly expense.<br>"
				+ "<b>Gas + Water: </b>Enter your total gas and water bill.<br>"
				+ "<b>Phone + TV: </b>Enter your total phone + TV bill.<br>"
				+ "<b>Child Care: </b>Enter your total child care expense.<br>"
				+ "<b>Commute: </b>Select whether you commute via transit or car (gas), then enter your total commute expense.<br>"
				+ "<b>Loans + Insurance: </b>Enter your total expenses from loans and insurance.</html>","Financial Help", JOptionPane.INFORMATION_MESSAGE);
	}
	protected void do_mnChildInformation_actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this,
				"<html><h2><center>Child Information</center</h2><br>"
				+ "<b>Child: </b>Select a child.<br>"
				+ "<b>Gender: </b>Select your child's gender.<br>"
				+ "<b>Date of Birth: </b>Enter child's date of birth.<br>"
				+ "<b>Age: </b>Enter your childs age.<br>"
				+ "<b>Clothing Size: </b>Select your child's size<br>"
				+ "<b>Shoe Size: </b>Enter your child's shoe size (01-20).<br>"
				+ "<b>Coat Size: </b>Enter your child's coat size (S, M, L,).<br>"
				+ "<b>Gaming System: </b>Select what game system your child has.<br>"
				+ "<b>Interests: </b>Select your childs intrest. Hold <i>CONTROL</i> to select multiple.</html>","Child Information Help", JOptionPane.INFORMATION_MESSAGE);
	}
	//Error checking
	private int selectedPane=tabbedPane.getSelectedIndex();
	private boolean infoConfirm=false;//Variable to check if user confirmed in the Info Pane
	private boolean financialConfirm=false;//Variable to check if user confirmed in the Financial Pane
	private boolean dialogsDisable=false;
	protected void do_tabbedPane_stateChanged(ChangeEvent e) {
		int notEmptyInfo=0;
		int notEmptyFinance=0;
		if(!dialogsDisable){
			//If it is the first run (happens on boot) the code message does not run 
			if(selectedPane==0 && firstRun>0){ //Checks on pane you are coming from
				if(firstNameTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter in your first name!");
				else
					notEmptyInfo++;
				if(lastNameTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter in your last name!");
				else
					notEmptyInfo++;
				if(addressTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your street address!");
				else
					notEmptyInfo++;
				if(cityComboBox.getSelectedIndex()==0)
					JOptionPane.showMessageDialog(this, "Select your city!");
				else
					notEmptyInfo++;
				if(zipTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your Zipcode!");
				else
					notEmptyInfo++;
				if(telephoneTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your phone number!");
				else
					notEmptyInfo++;
				if(emailTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your email address!");
				else
					notEmptyInfo++;
				//Runs the confirm dialog
				if(!infoConfirm&&notEmptyInfo>=7){ //The confirm button only appears once
					int done=JOptionPane.showConfirmDialog(this, "Are you sure your information is correct?","Are you done?", JOptionPane.YES_NO_OPTION);
					if(done==1)
						
				infoConfirm=true;
				}
			
			}
			//Error to not allow if you do not have any kids under 18 (Checks on pane you are going to)
			
			//Displays your total net for confirmation (Checks on pane you are coming from)
			if(selectedPane==1){
				if(totalIncomeTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your total income!");
				else
					notEmptyFinance++;
				if(rentTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your total home rent/mortgage!");
				else
					notEmptyFinance++;
				if(gasWaterTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your gas + water bill!");
				else
					notEmptyFinance++;
				if(phoneTVTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your phone + TV bill!");
				else
					notEmptyFinance++;
				if(childCareExpenseTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your total child care!");
				else
					notEmptyFinance++;
				if(commuteTF.getText().isEmpty()){
					JOptionPane.showMessageDialog(this, "Enter your commute!");
				}
				else
					notEmptyFinance++;
				
				if(!financialConfirm&&notEmptyFinance>5){
					JOptionPane.showConfirmDialog(this, "Your net amount is: "+netMoney, "Confirm", JOptionPane.DEFAULT_OPTION);
					financialConfirm=true;
				}
			}
			if(tabbedPane.getSelectedIndex()==2 && Integer.parseInt(child017Spinner.getValue()+"")==0){
				JOptionPane.showMessageDialog(this, "Your children do not qualify", "Error!", JOptionPane.ERROR_MESSAGE);
			}
			if(selectedPane==2 && Integer.parseInt(child017Spinner.getValue()+"")>0){
				if(childFirstNameTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your child's name!");
				if(dobTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your child's birthdate!");
					tabbedPane.setSelectedIndex(2);
				if(ageTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your child's age!");
				if(shoeTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your child's shoe size!");
				if(coatTF.getText().isEmpty())
					JOptionPane.showMessageDialog(this, "Enter your child's coat size!");
				
			}
		}
		selectedPane=tabbedPane.getSelectedIndex();//Updates to the current pane you are on
		firstRun=1;//allows messages to run after process has been booted
	}
	//Allows you to disable dialog messages
	protected void do_mntmDisableDialogs_stateChanged(ChangeEvent e) {
		if(mntmDisableDialogs.getState()==true)
			dialogsDisable=true;
		else
			dialogsDisable=false;
	}
}
