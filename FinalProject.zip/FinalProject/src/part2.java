import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class part2 {
	public static void main(String [] args){
		try{
			
			BufferedReader reader = new BufferedReader(new FileReader("Passenger_Weather_Combined.csv"));
			BufferedWriter writer = new BufferedWriter(new FileWriter("trip.csv"));
			Set <String> set= new TreeSet<String>();
			
			String [] attribute = new String [15];
			String [][] attributes= new String[77224][2];
			String line = reader.readLine();
			int number = 0;
			
			
			while(line != null){
				String[] att = line.split(",");
				for(int i = 0; i < att.length; i++)
					attribute[i]=att[i];
				attributes[number]=attribute;
				line = reader.readLine();
				
				set.add(attributes[number][9]+","+attributes[number][10]);
                
			}
			Iterator <String> itr=set.iterator();
			while (itr.hasNext()){
				String val=itr.next();
				writer.write(val);
				writer.newLine();
			}
			
			writer.close();
			reader.close();
		}
		catch(IOException e){}
	}
}
