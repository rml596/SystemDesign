import java.io.*; 
import java.util.*;
public class part1 {

	public static void main(String[] args) {
		int difStop=0;
		try{
			
			BufferedReader reader = new BufferedReader(new FileReader("Passenger_Weather_Combined.csv"));
			BufferedWriter writer = new BufferedWriter(new FileWriter("stop.csv"));
			Set <String> set= new TreeSet<String>();
			
			String [] attribute = new String [15];
			String [][] attributes= new String[77224][2];
			String line = reader.readLine();
			int number = 0;
			
			
			while(line != null){
				String[] att = line.split(",");
				for(int i = 0; i < att.length; i++)
					attribute[i]=att[i];
				attributes[number]=attribute;
				line = reader.readLine();
				
				set.add(attributes[number][2]);
                
			}
			Iterator <String> itr=set.iterator();
			while (itr.hasNext()){
				String val=itr.next();
				writer.write(val);
				writer.newLine();
				difStop++;
			}
			
			writer.close();
			reader.close();
			
		}
		catch(IOException e){}
		System.out.println(difStop+" unique stops");

	}

}
