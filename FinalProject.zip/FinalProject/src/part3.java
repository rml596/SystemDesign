import java.io.*;
import java.util.*;
public class part3 {
	public static void main(String[] args) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader("Passenger_Weather_Combined.csv"));
			BufferedWriter writer = new BufferedWriter(new FileWriter("Question3.csv"));
			TreeSet<String> set = new TreeSet<String>();
			String[][] attributes = new String[77224][15];
			String line = reader.readLine();
			int number = 0;

			while (line != null) {
				String[] att = line.split(",");
				attributes[number] = att;
				line = reader.readLine();
						number++;
			}
			reader.close();
			for (int i = 0; i < attributes.length; i++)
				set.add(attributes[i][2]);
			Iterator<String> it = set.iterator();
			int index=0;
			String[] stopIDS=new String[set.size()];
			while(it.hasNext()) {
				stopIDS [index]=it.next();
				index++;
			}
			
			
			writer.write("StopID,GoodWeather_Weekday_On,FairWeather_Weekday_On,BadWeather_Weekday_On,GoodWeather_Weekday_Off,FairWeather_Weekday_Off,BadWeather_Weekday_Off,GoodWeather_Weekend_On,FairWeather_Weekend_On,BadWeather_Weekend_On,GoodWeather_Weekend_Off,FairWeather_Weekend_Off,BadWeather_Weekend_Off");
			writer.newLine();
			for (int i=0;i<set.size();i++){
				String newStopId=stopIDS[i];
				
				double GoodWeekDayOn = 0;
				double FairWeekDayOn = 0;
				double BadWeekDayOn = 0;
				double GoodWeekDayOff = 0;
				double FairWeekDayOff = 0;
				double BadWeekDayOff = 0;
				
				
				
				double GoodWeekEndOn = 0;
				double FairWeekEndOn = 0;
				double BadWeekEndOn = 0;
				double GoodWeekEndOff = 0;
				double FairWeekEndOff = 0;
				double BadWeekEndOff = 0;
				
				int counter=0;
				for (int j = 0; j < attributes.length; j++) {
					if (newStopId.equals(attributes[j][2])) {
						counter++;
						if (attributes[j][7].equals("weekday")) {
							if (Double.parseDouble(attributes[j][14])>88){
								GoodWeekDayOn+=Double.parseDouble(attributes[j][4]);
								GoodWeekDayOff+=Double.parseDouble(attributes[j][5]);
							}
							if (Double.parseDouble(attributes[j][14])>68 && Double.parseDouble(attributes[j][14])>88){
								FairWeekDayOn+=Double.parseDouble(attributes[j][4]);
								FairWeekDayOff+=Double.parseDouble(attributes[j][5]);
							}
							if (Double.parseDouble(attributes[j][14])<68){
								BadWeekDayOn+=Double.parseDouble(attributes[j][4]);
								BadWeekDayOff+=Double.parseDouble(attributes[j][5]);
							}
						}
						else{
							if (Double.parseDouble(attributes[j][14])>88){
								GoodWeekEndOn+=Double.parseDouble(attributes[j][4]);
								GoodWeekEndOff+=Double.parseDouble(attributes[j][5]);
							}
							if (Double.parseDouble(attributes[j][14])>68 && Double.parseDouble(attributes[j][14])>88){
								FairWeekEndOn+=Double.parseDouble(attributes[j][4]);
								FairWeekEndOff+=Double.parseDouble(attributes[j][5]);
							}
							if (Double.parseDouble(attributes[j][14])<68){
								BadWeekEndOn+=Double.parseDouble(attributes[j][4]);
								BadWeekEndOff+=Double.parseDouble(attributes[j][5]);
							}
						}
					}
					
				}
				writer.write(newStopId+","+Double.toString(GoodWeekDayOn/counter)+","+Double.toString(FairWeekDayOn/counter)+","+Double.toString(BadWeekDayOn/counter)+Double.toString(GoodWeekDayOff/counter)+","+Double.toString(FairWeekDayOff/counter)+","+Double.toString(BadWeekDayOff/counter)+","+Double.toString(GoodWeekEndOn/counter)+","+Double.toString(FairWeekEndOn/counter)+","+Double.toString(BadWeekEndOn/counter)+","+","+Double.toString(GoodWeekEndOff/counter)+","+Double.toString(FairWeekEndOff/counter)+","+Double.toString(BadWeekEndOff/counter));
				writer.newLine();
			}
			writer.close();
		}
		catch (IOException e) {

		}
	}
}
