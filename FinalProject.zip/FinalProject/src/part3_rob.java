import java.io.*;
import java.util.*;

public class part3_rob {

	public static void main(String[] args) {
		try{
			
			BufferedReader reader = new BufferedReader(new FileReader("Passenger_Weather_Combined.csv"));
			BufferedWriter writer = new BufferedWriter(new FileWriter("question3.csv"));
			Set <String> set= new TreeSet<String>();
			
			String [] attribute = new String [15];
			String [][] attributes= new String[77224][2];
			String line = reader.readLine();
			int number = 0;
			ArrayList<Integer> goodWeatherWeekDayOn= new ArrayList<Integer>();
			ArrayList<Integer> fairWeatherWeekDayOn= new ArrayList<Integer>();
			ArrayList<Integer> badWeatherWeekDayOn= new ArrayList<Integer>();
			ArrayList<Integer> goodWeatherWeekDayOff= new ArrayList<Integer>();
			ArrayList<Integer> fairWeatherWeekDayOff= new ArrayList<Integer>();
			ArrayList<Integer> badWeatherWeekDayOff= new ArrayList<Integer>();
			
			double goodWeatherWeekDayOnAve=0;
			double fairWeatherWeekDayOnAve=0;
			double badWeatherWeekDayOnAve=0;
			double goodWeatherWeekDayOffAve=0;
			double fairWeatherWeekDayOffAve=0;
			double badWeatherWeekDayOffAve=0;
			
			ArrayList<Integer> goodWeatherWeekEndOn= new ArrayList<Integer>();
			ArrayList<Integer> fairWeatherWeekEndOn= new ArrayList<Integer>();
			ArrayList<Integer> badWeatherWeekEndOn= new ArrayList<Integer>();
			ArrayList<Integer> goodWeatherWeekEndOff= new ArrayList<Integer>();
			ArrayList<Integer> fairWeatherWeekEndOff= new ArrayList<Integer>();
			ArrayList<Integer> badWeatherWeekEndOff= new ArrayList<Integer>();
			
			double goodWeatherWeekEndOnAve=0;
			double fairWeatherWeekEndOnAve=0;
			double badWeatherWeekEndOnAve=0;
			double goodWeatherWeekEndOffAve=0;
			double fairWeatherWeekEndOffAve=0;
			double badWeatherWeekEndOffAve=0;
			
			
			
			while(line != null){
				String[] att = line.split(",");
				for(int i = 0; i < att.length; i++)
					attribute[i]=att[i];
				attributes[number]=attribute;
				line = reader.readLine();
				
				if(set.add(attributes[number][2])){
					if(attributes[number][7].equals("weekday")){
						if(Double.parseDouble(attributes[number][4])>0){
							if(Double.parseDouble(attributes[number][14])>88){
								goodWeatherWeekDayOn.add(Integer.parseInt(attributes[number][4]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								goodWeatherWeekDayOnAve=(goodWeatherWeekDayOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
							else if(Double.parseDouble(attributes[number][14])<=88&&Double.parseDouble(attributes[number][14])>68){
								fairWeatherWeekDayOn.add(Integer.parseInt(attributes[number][4]));
								
								goodWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								fairWeatherWeekDayOnAve=(fairWeatherWeekDayOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
							else{
								badWeatherWeekDayOn.add(Integer.parseInt(attributes[number][4]));
								fairWeatherWeekDayOn.add(0);
								
								goodWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								badWeatherWeekDayOnAve=(badWeatherWeekDayOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
						}
						
						
						else if(Double.parseDouble(attributes[number][4])==0){
							badWeatherWeekDayOn.add(0);
							fairWeatherWeekDayOn.add(0);
							
							goodWeatherWeekDayOn.add(0);
							goodWeatherWeekDayOff.add(0);
							fairWeatherWeekDayOff.add(0);
							badWeatherWeekDayOff.add(0);
							goodWeatherWeekEndOn.add(0);
							fairWeatherWeekEndOn.add(0);
							badWeatherWeekEndOn.add(0);
							goodWeatherWeekEndOff.add(0);
							fairWeatherWeekEndOff.add(0);
							badWeatherWeekEndOff.add(0);
						}
						
						
						
						if(Integer.parseInt(attributes[number][5])>0){
							if(Double.parseDouble(attributes[number][14])>88){
								goodWeatherWeekDayOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								
								goodWeatherWeekDayOn.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								goodWeatherWeekDayOffAve=(goodWeatherWeekDayOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
							else if(Double.parseDouble(attributes[number][14])<=88&&Double.parseDouble(attributes[number][14])>68){
								fairWeatherWeekDayOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								
								goodWeatherWeekDayOn.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								fairWeatherWeekDayOffAve=(fairWeatherWeekDayOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
							else{
								badWeatherWeekDayOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								
								goodWeatherWeekDayOn.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								badWeatherWeekDayOffAve=(badWeatherWeekDayOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
						}
						else if(Double.parseDouble(attributes[number][5])==0){
							badWeatherWeekDayOn.add(0);
							fairWeatherWeekDayOn.add(0);
							
							goodWeatherWeekDayOn.add(0);
							goodWeatherWeekDayOff.add(0);
							fairWeatherWeekDayOff.add(0);
							badWeatherWeekDayOff.add(0);
							goodWeatherWeekEndOn.add(0);
							fairWeatherWeekEndOn.add(0);
							badWeatherWeekEndOn.add(0);
							goodWeatherWeekEndOff.add(0);
							fairWeatherWeekEndOff.add(0);
							badWeatherWeekEndOff.add(0);
						}
					}
					
					else{
						if(Integer.parseInt(attributes[number][4])>0){
							if(Double.parseDouble(attributes[number][14])>88){
								goodWeatherWeekEndOn.add(Integer.parseInt(attributes[number][4]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								
								goodWeatherWeekDayOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								goodWeatherWeekEndOnAve=(goodWeatherWeekEndOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
							else if(Double.parseDouble(attributes[number][14])<=88&&Double.parseDouble(attributes[number][14])>68){
								fairWeatherWeekEndOn.add(Integer.parseInt(attributes[number][4]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								
								goodWeatherWeekDayOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOnAve=(fairWeatherWeekEndOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
							else{
								badWeatherWeekEndOn.add(Integer.parseInt(attributes[number][4]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								
								goodWeatherWeekDayOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								badWeatherWeekEndOnAve=(badWeatherWeekEndOnAve+Integer.parseInt(attributes[number][4]))/2;
							}
						}
						
						else if(Double.parseDouble(attributes[number][4])==0){
							badWeatherWeekDayOn.add(0);
							fairWeatherWeekDayOn.add(0);
							
							goodWeatherWeekDayOn.add(0);
							goodWeatherWeekDayOff.add(0);
							fairWeatherWeekDayOff.add(0);
							badWeatherWeekDayOff.add(0);
							goodWeatherWeekEndOn.add(0);
							fairWeatherWeekEndOn.add(0);
							badWeatherWeekEndOn.add(0);
							goodWeatherWeekEndOff.add(0);
							fairWeatherWeekEndOff.add(0);
							badWeatherWeekEndOff.add(0);
						}
						
						
						if(Integer.parseInt(attributes[number][5])>0){
							if(Double.parseDouble(attributes[number][14])>88){
								goodWeatherWeekEndOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekDayOn.add(0);
								fairWeatherWeekEndOff.add(0);
								badWeatherWeekEndOff.add(0);
								goodWeatherWeekEndOffAve=(goodWeatherWeekEndOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
							else if(Double.parseDouble(attributes[number][14])<=88&&Double.parseDouble(attributes[number][14])>68){
								fairWeatherWeekEndOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								goodWeatherWeekDayOn.add(0);
								badWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOffAve=(fairWeatherWeekEndOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
							else{
								badWeatherWeekEndOff.add(Integer.parseInt(attributes[number][5]));
								fairWeatherWeekDayOn.add(0);
								badWeatherWeekDayOn.add(0);
								goodWeatherWeekDayOff.add(0);
								fairWeatherWeekDayOff.add(0);
								badWeatherWeekDayOff.add(0);
								goodWeatherWeekEndOn.add(0);
								fairWeatherWeekEndOn.add(0);
								badWeatherWeekEndOn.add(0);
								goodWeatherWeekEndOff.add(0);
								fairWeatherWeekEndOff.add(0);
								
								goodWeatherWeekDayOn.add(0);
								badWeatherWeekEndOffAve=(badWeatherWeekEndOffAve+Integer.parseInt(attributes[number][5]))/2;
							}
						}
						
						
						else if(Double.parseDouble(attributes[number][5])==0){
							badWeatherWeekDayOn.add(0);
							fairWeatherWeekDayOn.add(0);
							
							goodWeatherWeekDayOn.add(0);
							goodWeatherWeekDayOff.add(0);
							fairWeatherWeekDayOff.add(0);
							badWeatherWeekDayOff.add(0);
							goodWeatherWeekEndOn.add(0);
							fairWeatherWeekEndOn.add(0);
							badWeatherWeekEndOn.add(0);
							goodWeatherWeekEndOff.add(0);
							fairWeatherWeekEndOff.add(0);
							badWeatherWeekEndOff.add(0);
						}
						
						
						
					}
                	
                }
			}
			writer.write("StopID,GoodWeather_WeekDay_On,FairWeather_WeekDay_On,BadWeather_WeekDay_On,GoodWeather_WeekDay_Off,FairWeather_WeekDay_Off,BadWeather_WeekDay_Off,GoodWeather_WeekEnd_On,FairWeather_WeekEnd_On,BadWeather_WeekEnd_On,GoodWeather_WeekEnd_Off,FairWeather_WeekEnd_Off,BadWeather_WeekEnd_Off");
			Iterator <String> itr=set.iterator();
			int i=0;
			while (itr.hasNext()){
				String val=itr.next();
				writer.write(val+","+goodWeatherWeekDayOn.get(i)+","+fairWeatherWeekDayOn.get(i)+","+badWeatherWeekDayOn.get(i)+","+goodWeatherWeekDayOff.get(i)+","+fairWeatherWeekDayOff.get(i)+","+badWeatherWeekDayOff.get(i)+","+goodWeatherWeekEndOn.get(i)+","+fairWeatherWeekEndOn.get(i)+","+badWeatherWeekEndOn.get(i)+","+goodWeatherWeekEndOff.get(i)+","+fairWeatherWeekEndOff.get(i)+","+badWeatherWeekEndOff.get(i));
				//System.out.println(val+","+goodWeatherWeekDayOn.get(i)+","+fairWeatherWeekDayOn.get(i)+","+badWeatherWeekDayOn.get(i)+","+goodWeatherWeekDayOff.get(i)+","+fairWeatherWeekDayOff.get(i)+","+badWeatherWeekDayOff.get(i)+","+goodWeatherWeekEndOn.get(i)+","+fairWeatherWeekEndOn.get(i)+","+badWeatherWeekEndOn.get(i)+","+goodWeatherWeekEndOff.get(i)+","+fairWeatherWeekEndOff.get(i)+","+badWeatherWeekEndOff.get(i));
				writer.newLine();
				i++;
			}
			//System.out.println(goodWeatherWeekDayOn.size()+"\n"+fairWeatherWeekDayOn.size()+"\n"+badWeatherWeekDayOn.size()+"\n"+goodWeatherWeekDayOff.size()+"\n"+fairWeatherWeekDayOff.size()+"\n"+badWeatherWeekDayOff.size()+"\n"+goodWeatherWeekEndOn.size()+"\n"+fairWeatherWeekEndOn.size()+"\n"+badWeatherWeekEndOn.size()+"\n"+goodWeatherWeekEndOff.size()+"\n"+fairWeatherWeekEndOff.size()+"\n"+badWeatherWeekEndOff.size());
			//System.out.println(set.size());
			System.out.println("Good Weather Weekday On Ave = "+goodWeatherWeekDayOnAve);
			
			
			
			writer.close();
			reader.close();
			
		}
		catch(IOException e){}

	}

}
