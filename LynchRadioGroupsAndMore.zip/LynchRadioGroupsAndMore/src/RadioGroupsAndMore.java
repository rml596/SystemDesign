import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import java.awt.Font;

public class RadioGroupsAndMore extends JFrame {

	private JPanel contentPane;
	private final JLabel lblChooseOne = new JLabel("Choose One");
	private final JRadioButton rdbtnOne = new JRadioButton("One");
	private final JRadioButton rdbtnTwo = new JRadioButton("Two");
	private final JRadioButton rdbtnThree = new JRadioButton("Three");
	private final JRadioButton rdbtnFour = new JRadioButton("Four");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JLabel lblChoice = new JLabel("");
	private final JCheckBox chckbxFirst = new JCheckBox("First");
	private final JCheckBox chckbxSecond = new JCheckBox("Second");
	private final JCheckBox chckbxThird = new JCheckBox("Third");
	private final JTextArea checkedBoxTextArea = new JTextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RadioGroupsAndMore frame = new RadioGroupsAndMore();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RadioGroupsAndMore() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Lynch Radio Button");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblChooseOne.setBounds(79, 56, 85, 16);
		
		contentPane.add(lblChooseOne);
		buttonGroup.add(rdbtnOne);
		rdbtnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnOne_actionPerformed(e);
			}
		});
		rdbtnOne.setBounds(89, 84, 141, 23);
		
		contentPane.add(rdbtnOne);
		buttonGroup.add(rdbtnTwo);
		rdbtnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnTwo_actionPerformed(e);
			}
		});
		rdbtnTwo.setBounds(89, 113, 141, 23);
		
		contentPane.add(rdbtnTwo);
		buttonGroup.add(rdbtnThree);
		rdbtnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThree_actionPerformed(e);
			}
		});
		rdbtnThree.setBounds(89, 148, 141, 23);
		
		contentPane.add(rdbtnThree);
		buttonGroup.add(rdbtnFour);
		rdbtnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFour_actionPerformed(e);
			}
		});
		rdbtnFour.setBounds(89, 181, 141, 23);
		
		contentPane.add(rdbtnFour);
		lblChoice.setBounds(283, 56, 114, 16);
		
		contentPane.add(lblChoice);
		chckbxFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxFirst_actionPerformed(e);
			}
		});
		chckbxFirst.setBounds(269, 84, 128, 23);
		
		contentPane.add(chckbxFirst);
		chckbxSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxSecond_actionPerformed(e);
			}
		});
		chckbxSecond.setBounds(269, 113, 128, 23);
		
		contentPane.add(chckbxSecond);
		chckbxThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxThird_actionPerformed(e);
			}
		});
		chckbxThird.setBounds(269, 148, 128, 23);
		
		contentPane.add(chckbxThird);
		checkedBoxTextArea.setFont(new Font("Lucida Grande", Font.PLAIN, 8));
		checkedBoxTextArea.setBounds(269, 181, 161, 91);
		
		contentPane.add(checkedBoxTextArea);
	}
	protected void do_rdbtnFour_actionPerformed(ActionEvent e) {
		lblChoice.setText(rdbtnFour.getText());
	}
	protected void do_rdbtnThree_actionPerformed(ActionEvent e) {
		lblChoice.setText(rdbtnThree.getText());
	}
	protected void do_rdbtnOne_actionPerformed(ActionEvent e) {
		lblChoice.setText(rdbtnOne.getText());
	}
	protected void do_rdbtnTwo_actionPerformed(ActionEvent e) {
		lblChoice.setText(rdbtnTwo.getText());
	}
	protected void do_chckbxFirst_actionPerformed(ActionEvent e) {
		String first= new String();
		String second= new String();
		String third= new String();
		if(chckbxFirst.isSelected())
			first="First\n";
		if(chckbxSecond.isSelected())
			second="Second\n";
		if(chckbxThird.isSelected())
			third="Third\n";
		checkedBoxTextArea.setText(first+second+third);
				
	}
	protected void do_chckbxThird_actionPerformed(ActionEvent e) {
		do_chckbxFirst_actionPerformed(e);
	}
	protected void do_chckbxSecond_actionPerformed(ActionEvent e) {
		do_chckbxFirst_actionPerformed(e);
	}
}
